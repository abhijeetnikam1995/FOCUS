

/* External Libs : Libraries : Jsoup , Apache commons.lang

*/


package focus;


import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


/**
 *
 * @author rakesh
 */

public class FOCUS  {

    /**
     *
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {

        new Config();
        
    }
    
}
